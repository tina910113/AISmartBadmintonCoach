from PoseModule import PoseDetector
import cv2
import numpy as np
import pyttsx3

def Long(file_filename):
    
    # 讀取影片檔案
    cap = cv2.VideoCapture(file_filename)

    # 取得影片的寬高
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    cv2.namedWindow('Pose', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('Pose', width, height)

    detector = PoseDetector()
    engine = pyttsx3.init()
    text = 'Right foot needs to step back'
    text1 ='Elbow needs to be raised'
    dir = 0 
    count = 0
    while True:
    
        success, img = cap.read()
        if success:
            
            img = cv2.resize(img, (640, 480))
            h, w, c = img.shape
            
            pose, img = detector.findPose(img, draw=True)
            if pose:
                lmList = pose["lmList"]
                angle, img = detector.findAngle(lmList[14], lmList[12],lmList[24], img)
                
                rightFooty = lmList[26][1]
                leftFooty = lmList[25][1]
                bar = np.interp(angle, (0, 180), (w//2-100, w//2+100))

                if angle <= 90 and rightFooty < leftFooty : 
                    if dir == 0:
                        count = count + 0.5
                        dir = 1 
                if angle >= 150 : 
                    if dir == 1:
                        count = count + 0.5
                        dir = 0
                        engine.say("perfact")
                        engine.runAndWait()

                if rightFooty > leftFooty:
                    cv2.putText(img, text, (10, 400), cv2.FONT_HERSHEY_TRIPLEX,1, (0, 0, 255), 1, cv2.LINE_AA)
                else:
                    cv2.putText(img, text1, (10, 350), cv2.FONT_HERSHEY_TRIPLEX,1, (0, 0, 255), 1, cv2.LINE_AA) 
                msg = str(int(count))        
                cv2.putText(img, msg, (0, 120),cv2.FONT_HERSHEY_SIMPLEX, 5,(0, 0, 0), 10)
            
            cv2.imshow("Pose", img)
        else:
            break
        if cv2.waitKey(1) & 0xFF == ord("q"):
            engine.say("The end")
            engine.runAndWait()
            break

    cap.release()
    cv2.destroyAllWindows()