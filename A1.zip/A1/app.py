import os
import pymysql
# 載入 Flask, render_template, request ,url_for(轉址的函式)
from flask import Flask, render_template, request, redirect, url_for, session, g, flash, send_from_directory, send_file, jsonify, json
from dataclasses import dataclass
from werkzeug.utils import secure_filename
from flask_sqlalchemy import SQLAlchemy #資料庫
from sqlalchemy import ForeignKey
from sqlalchemy import text
from sqlalchemy.sql.expression import func
from sqlalchemy import func
from sqlalchemy import Sequence
# from config import Config
import subprocess
# from form import FormRegister
from flask_login import LoginManager

from Long_Video import Long
from LongBackHand_Video import LongBackHand
from Short_Video import Short
from BackHandFlick_Video import BackHandFlick
from ForeHandFlick_Video import ForeHandFlick
# from drive import drive

# Flask 類別 初始化時 傳入的 __name__ 參數，代表當前模組的名稱。是固定用法，以便讓 Flask 知道在哪裡尋找資源。
app = Flask(__name__)
# app.config.from_object(Config)
# 用於加密 session 資訊
app.config['SECRET_KEY'] = "Sam19YING02"
# app.secret_key = 'Sam19YING02'  

# #MySQL
# 设置数据库连接地址
DB_URI_1  = "mysql+pymysql://root:root@localhost:3306/db_badminton"
# DB_URI_2  = "mysql+pymysql://root:root@localhost:3306/db_login"

app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI_1
# app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI_2

# app.config['SQLALCHEMY_BINDS'] = {
#     'db_badminton': 'mysql+mysqlconnector://root:root@localhost:3306/db_badminton',
#     'db_login': 'mysql+mysqlconnector://root:root@localhost:3306/db_login'
# }

# 是否追踪数据库修改，一般不开启, 会影响性能
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# 是否显示底层执行的SQL语句
app.config['SQLALCHEMY_ECHO'] = True
# 初始化组件对象, 直接关联Flask应用
db = SQLAlchemy(app)

# 定義User模型
class User(db.Model):
    # __bind_key__ = 'db_login'
    # __bind_key__ = 'db_badminton'
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    # record_id = db.Column(db.Integer, default=0)
    # players = db.relationship('Player', backref='user')
    def __init__(self, username, password):
        self.username = username
        self.password = password

# 定義Player模型
class Player(db.Model):
    # __bind_key__ = 'db_badminton'
    __tablename__ = 'player'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    # id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, ForeignKey('user.id'))
    # name = db.Column(db.String(100), db.ForeignKey('user.username'))
    name = db.Column(db.String(100))
    # user_id = db.Column(db.Integer, ForeignKey('users.id'), nullable=False)
    shot = db.Column(db.String(100))
    training_progress = db.Column(db.Integer)
    complete_progress = db.Column(db.Integer)
    percentage = db.Column(db.Float)
    date = db.Column(db.TIMESTAMP)
    # record_number = db.Column(db.Integer, default=0)
    # user = relationship('User')

UPLOAD_FOLDER = './static/uploads' #檔案上傳的路徑
ALLOWED_EXTENSIONS = set(['mp4', 'avi', 'mov', 'wmv', 'flv', 'mkv', 'oog', 'avchd','MJPG']) # 限制檔案的格式
# 設置static目錄路徑
static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), './static/uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


# 函式
# 1
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS
# 2
def reassign_record_numbers(user_id):
    players = Player.query.filter_by(user_id=user_id).order_by(Player.id).all()
    for idx, player in enumerate(players, start=1):
        player.id = idx
    db.session.commit()

# 使用函式裝飾器，建立一個路由，可針對主網域 / 發出請求 裝飾器是告訴 Flask，哪個 URL 應該觸發我們的函式。斜線代表的就是網站的根目錄，可以疊加。
# 首頁
@app.route('/')
def home():     # 發出請求後會執行 home() 的函式
    return render_template('home.html')     # 執行函式後會回傳特定的網頁內容

# @app.route('/index', methods=['GET', 'POST'])
# def index():
#     return render_template('index.html')

# 字典
# users = [
#     {'username': 'asd', 'password': '1'}
# ]

@app.before_request
def before_request():
    g.user = None
    if 'username' in session:
        user = User.query.filter_by(username=session['username']).first()
        g.user = user
        # if not user:
        #     return redirect('/login')
        # # 查詢該帳號下的最大編號
        # max_record_number = db.session.query(db.func.max(Player.record_number)).filter_by(user_id=user.id).scalar()
        # if max_record_number is not None:
        #     g.record_number = max_record_number + 1
        # else:
        #     g.record_number = 1

# 註冊
@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        repassword = request.form['repassword']
        # 檢查帳號名是否已存在
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            return '帳號已被註冊'
        # 判斷兩次密碼是否一致並檢查是否有輸入帳號和密碼
        if password == repassword and password != '' and username != '':
            new_user = User(username=username, password=password)
            db.session.add(new_user)
            # # 檢查該使用者是否已經有紀錄，如果沒有則設置第一個紀錄編號為 1
            # if not existing_user:
            #     new_user.record_id = 1
            db.session.commit()
            return redirect('/login')
        return "兩次密碼不一致,或未輸入密碼"
    return render_template('register.html')
    #     new_user = User(username=username, password=password)
        
    #     db.session.add(new_user)
    #     db.session.commit()
    #     return redirect('/login')
    # return render_template('register.html')

# 登入
@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        session.pop('username',None)
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            g.user = user
            session['username'] = username
            return redirect('/menu')
        else:
            return "登入失敗"
    return render_template('login.html')

# 登出
@app.route('/logout', methods=['POST', 'GET'])
def logout():
    session.pop('username', None)
    return redirect('/login')

# 選單
@app.route('/menu', methods=['POST', 'GET'])
def menu():
    if not g.user:
        return redirect('/login')
    return render_template('menu.html')

# 系統使用說明
@app.route('/explanation', methods=['POST', 'GET'])
def explanation():
    if not g.user:
        return redirect('/login')
    return render_template('explanation.html')

# 影片範例
@app.route('/explanation_video', methods=['POST', 'GET'])
def explanation_video():
    if not g.user:
        return redirect('/login')
    return render_template('explanation_video.html')

# 進度表
@app.route('/schedule', methods=['POST', 'GET'])
def schedule():
    if not g.user:
        return redirect('/login')
    
    #  获取当前登录用户的信息
    current_user = User.query.filter_by(username=session['username']).first()

    players = Player.query.filter_by(user_id=current_user.id).all()
    
    if request.method == 'POST':
        
        selected_id = request.form['selected_id']
        # 存在 selected_id，执行修改操作
        if selected_id:
            action = request.form['action']
            player = Player.query.get(selected_id)
            if player and player.user_id == current_user.id:
                if action == 'update':  # 如果是更新操作
                    player.name = request.form['name']
                    player.shot = request.form['shot']
                    player.training_progress = int(request.form['training_progress'])
                    player.complete_progress = int(request.form['complete_progress'])
                    player.percentage = round((player.complete_progress / player.training_progress) * 100, 2) if player.training_progress != 0 else 0
                    player.date = request.form['date']
                    db.session.commit()  # 提交更改，保存到数据库
                elif action == 'delete':  # 如果是删除操作
                    db.session.delete(player)
                    db.session.commit()
        # 不存在 selected_id，执行新增操作
        else:
            name = request.form['name']
            shot = request.form['shot']
            training_progress = int(request.form['training_progress'])
            complete_progress = int(request.form['complete_progress'])
            percentage = round((complete_progress /training_progress) * 100, 2) if training_progress != 0 else 0
            date = request.form['date']

            # if player and player.user_id == current_user.id:
            #     db.session.delete(player)
            #     db.session.commit()
            #     # 重排剩下的紀錄編號
            #     reassign_record_numbers(current_user.id)

            # 根据用户名查找关联的 User 记录
            # user = User.query.filter_by(username=name).first()
            # if user:
            #     # 创建 Player 对象并关联到 User
            player = Player(user_id=current_user.id, name=name, shot=shot, training_progress=training_progress, complete_progress=complete_progress, percentage=percentage, date=date)
            db.session.add(player)
            db.session.commit()  # 提交更改，保存到数据库

            # 刪除紀錄後重新調整編號
            # db.session.execute(text("ALTER TABLE player AUTO_INCREMENT = 1;"))
        # reassign_record_numbers()
        # 重定向到显示所有记录的页面
        return redirect('/schedule')
    # # 查询当前登录用户的所有进度记录
    # current_user_players = Player.query.filter_by(user_id=current_user.id).all()
    return render_template('schedule.html', players=players)

# 查看紀錄
@app.route('/view/<int:selected_id>', methods = ['GET','POST'])
def view(selected_id):
    if not g.user:
        return redirect('/login')
    players = Player.query.all()
    return render_template('view.html', players=players, selected_id=selected_id)

# 新增紀錄
@app.route('/add', methods = ['GET','POST'])
def add():
    if not g.user:
        return redirect('/login')
    players = Player.query.all()
    return render_template('add.html', players=players)

# 修改紀錄
@app.route('/edit/<int:selected_id>', methods = ['GET','POST'])
def edit(selected_id):
    if not g.user:
        return redirect('/login')
    players = Player.query.all()
    return render_template('edit.html', players=players, selected_id=selected_id)

# 刪除紀錄
@app.route('/delete/<int:selected_id>', methods = ['GET','POST'])
def delete(selected_id):
    if not g.user:
        return redirect('/login')
    # players = Player.query.get(selected_id)
    players = Player.query.all()
    # db.session.delete(players)
    # db.session.commit()
    # return redirect(url_for('schedule'))
    return render_template('delete.html', players=players, selected_id=selected_id)

# 删除记录后重新排列編號
def renumber_players(user_id):
    # 查询用户的所有记录，并按照id升序排列
    players = Player.query.filter_by(user_id=user_id).order_by(Player.id).all()

    # 重新排列編號并更新数据库
    for i, player in enumerate(players, start=1):
        player.id = i
    
    db.session.commit()

# 選擇訓練方式
@app.route('/choose', methods = ['GET','POST'])
def choose():
    if not g.user:
        return redirect('/login')
    return render_template('start.html')

# 影片辨識
@app.route('/video', methods = ['GET','POST'])
def video():
    if not g.user:
        return redirect('/login')
    return render_template('train.html')

# 及時辨識
@app.route('/realtime', methods = ['GET','POST'])
def realtime():
    if not g.user:
        return redirect('/login')
    return render_template('realtime.html')

# 影片辨識(主程式)
@app.route('/train', methods = ['GET','POST'])
def train():
    if not g.user:
        return redirect('/login')
    if request.method == 'POST': # 使用者使用POST時執行
         # 獲取使用者上傳的檔案 #'file'=>在(start.html)name=file
        file = request.files['file']
        if file and allowed_file(file.filename):
           
            file_filename = secure_filename(file.filename)
            # processed_filename = process_video(file_filename)
            # 儲存檔案到伺服器
            # file.save(os.path.join(app.config['UPLOAD_FOLDER'], file_filename))
            # return redirect(url_for('train', file_filename=file_filename))
            file.save(file_filename)
        
            
            training_option = request.form['training_option']   # [POST] # 使用request.form取得前端的training_option
            # training_option = request.args.get('training_option') #GET
            # 在這裡添加將"training_option"傳遞到AI模型的程式碼
            if training_option == "正手長球" :
                # subprocess.Popen(['python', 'Long.py']) #OK
                Long(file_filename) #OK
            elif training_option == "反手長球" :
                # subprocess.Popen(['python', 'longbackhand3.py'])
                LongBackHand(file_filename)
                # return "訓練已經開始! 訓練項目: {}".format(training_option)
            elif training_option == "正手小球" :
                Short(file_filename)
            elif training_option == "反手小球" :
                Short(file_filename)
            elif training_option == "正手挑球" :
                BackHandFlick(file_filename)
            elif training_option == "反手挑球" :
                ForeHandFlick(file_filename)
            # elif training_option == "平球" :
                # subprocess.Popen(['python', 'drive.py'])
                # drive(file_filename)
                # return "訓練已經開始! 訓練項目: {}".format(training_option)

    # return "訓練已經完成! 訓練項目: {}".format(training_option)
    return redirect(url_for('video'))
    # return redirect(url_for('upload', file_filename=file_filename))
    # return redirect(url_for('show_processed_video', file_filename=file_filename))

# 及時辨識(主程式)
@app.route('/real_Time', methods = ['GET','POST'])
def real_Time():
    if not g.user:
        return redirect('/login')
    if request.method == 'POST':
        
        training_option = request.form['training_option']   # [POST] # 使用request.form取得前端的training_option
        # training_option = request.args.get('training_option') #GET
        # 在這裡添加將"training_option"傳遞到AI模型的程式碼
        if training_option == "正手長球" :
            subprocess.Popen(['python', 'Long.py']) #OK
            # Long(file_filename) #OK

        elif training_option == "反手長球" :
            subprocess.Popen(['python', 'Longbackhand.py'])
            # LongBackHand3(file_filename)
        elif training_option == "正手小球" :
            subprocess.Popen(['python', 'Short.py'])
        elif training_option == "反手小球" :
            subprocess.Popen(['python', 'Short.py'])
        elif training_option == "正手挑球" :
            subprocess.Popen(['python', 'ForeHandFlick.py'])
        elif training_option == "反手挑球" :
            subprocess.Popen(['python', 'BackHandFlick.py'])
        # elif training_option == "平球" :
            # subprocess.Popen(['python', 'drive.py'])
            # drive(file_filename)
            # return "訓練已經開始! 訓練項目: {}".format(training_option)

    # return "訓練已經完成! 訓練項目: {}".format(training_option)
    return redirect(url_for('realtime'))


if __name__ == '__main__':
    # db.create_all()
    # app.run()
    # app.run(host='192.168.0.5',port='5000',debug=True)
    # app.run(host='192.168.74.167',port='5000',debug=True)
    # app.run(host='220.136.220.169',port='5000',debug=True)
    app.run(host='0.0.0.0',port='5000',debug=True)
    # app.run(debug=True)